package com.glassbrowser

import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var url: EditText

    private val sites = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Wikipedia" to "https://www.wikipedia.org",
        "Reddit" to "https://www.reddit.com",
        "Pinterest" to "https://www.pinterest.com",
        "Archive.org" to "https://archive.org",
        "Commons" to "https://commons.wikimedia.org",
        "Unsplash" to "https://unsplash.com",
        "Pexels" to "https://www.pexels.com",
        "Vimeo" to "https://vimeo.com",
        "Dailymotion" to "https://www.dailymotion.com",
        "Imgur" to "https://imgur.com",
        "GitHub" to "https://github.com"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        url = findViewById(R.id.url)
        val bar = findViewById<ProgressBar>(R.id.bar)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            if (Build.VERSION.SDK_INT >= 33) isAlgorithmicDarkeningAllowed = true
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) { url.setText(u) }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                bar.progress = p
                bar.visibility = if (p < 100) View.VISIBLE else View.GONE
            }
        }
        web.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        web.setOnLongClickListener {
            val r = web.hitTestResult
            val img = r.type == WebView.HitTestResult.IMAGE_TYPE ||
                r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            if (img && r.extra != null) {
                AlertDialog.Builder(this).setTitle("Save image?")
                    .setPositiveButton("Download") { _, _ ->
                        download(r.extra!!, web.settings.userAgentString, null, null)
                    }.setNegativeButton("Cancel", null).show()
                true
            } else false
        }

        findViewById<Button>(R.id.go).setOnClickListener { go() }
        findViewById<Button>(R.id.paste).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank()) { url.setText(t.trim()); go() }
        }
        findViewById<Button>(R.id.theme).setOnClickListener {
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            AppCompatDelegate.setDefaultNightMode(
                if (night) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES)
        }
        url.setOnEditorActionListener { _, id, e ->
            if (id == EditorInfo.IME_ACTION_GO || e?.keyCode == KeyEvent.KEYCODE_ENTER) { go(); true } else false
        }

        val chips = findViewById<LinearLayout>(R.id.chips)
        val d = resources.displayMetrics.density
        sites.forEach { (name, link) ->
            chips.addView(TextView(this).apply {
                text = name
                setTextColor(getColor(R.color.text))
                setBackgroundResource(R.drawable.glass)
                gravity = Gravity.CENTER
                setPadding((16 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = (8 * d).toInt() }
                setOnClickListener { url.setText(link); go() }
            })
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
        web.loadUrl("https://www.google.com")
    }

    private fun go() {
        val t = url.text.toString().trim()
        if (t.isEmpty()) return
        val target = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(target)
        url.clearFocus()
    }

    private fun download(u: String, ua: String?, cd: String?, mime: String?) {
        try {
            val req = DownloadManager.Request(Uri.parse(u))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(u, cd, mime))
            if (!mime.isNullOrBlank()) req.setMimeType(mime)
            if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(u)?.let { req.addRequestHeader("Cookie", it) }
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "Downloading… saved to Downloads", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Can't download this link", Toast.LENGTH_SHORT).show()
        }
    }
}
